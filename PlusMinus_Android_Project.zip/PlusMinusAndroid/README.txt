PLUS-MINUS Android Build Project

This project wraps the included offline Plus-Minus bot game in an Android WebView.
Features included:
- 1 human + 3 bots
- 52-card deck
- 5 + 4 + 4 dealing
- bidding
- Hukum/trump
- trick play
- 10-hand option
- scoring and target
- custom Plus-Minus app icon

To build:
1. Open this folder in Android Studio.
2. Let Gradle sync/download the Android Gradle Plugin and Android SDK platform required by compileSdk 35.
3. Build > Build APK(s).
4. Install the generated debug APK on Android.

No internet permission is requested by the app.
